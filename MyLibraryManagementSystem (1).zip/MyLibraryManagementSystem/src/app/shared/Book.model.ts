export class Book{
    constructor(public name:string,public author:string,
        public quantity:number,public imagepath?:string){

    }
}