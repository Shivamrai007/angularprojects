export class Book{
    private name:string;
    private author:string;
    private quantity:number;
    private imagepath:string;
}